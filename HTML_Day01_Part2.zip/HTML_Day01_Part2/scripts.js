let el = document.getElementById("response");
const doFirst = function() {
  el.innerHTML = el.innerHTML + "I was first...";
};
//
doFirst();
//
el.innerHTML = el.innerHTML + "<br />And I am second!";

