let el = document.getElementById("response");
const doFirst = function() {
  return new Promise((resolve, reject)=>{
    setTimeout(()=>{
      resolve("I was first...");
    },1000);
  });
};
//
doFirst().then((data)=>{
  el.innerHTML = el.innerHTML + data + "<br />And I am second!";
});

