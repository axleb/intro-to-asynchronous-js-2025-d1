let el = document.getElementById("response");
//
function showData(){
  el.innerHTML = "From showData()";  
};

