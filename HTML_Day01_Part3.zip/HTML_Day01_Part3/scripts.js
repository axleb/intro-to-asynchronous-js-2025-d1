let el = document.getElementById("response");
const doFirst = function() {
  return new Promise(function(resolve, reject){
    setTimeout(function(){
      resolve("<br />I was first...");
    }, 1000);
  });
};
//
doFirst()
.then(function(data){
  el.innerHTML = el.innerHTML + data;
  el.innerHTML = el.innerHTML + "<br />And I am second!";
});	
